﻿using System.Reflection;

[assembly: AssemblyTitle("The last comparison library you'll ever need!")]
