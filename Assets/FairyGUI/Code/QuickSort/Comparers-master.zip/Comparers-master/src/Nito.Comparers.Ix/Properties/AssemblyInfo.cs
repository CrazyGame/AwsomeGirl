﻿using System.Reflection;

[assembly: AssemblyTitle("Comparer extensions for Interactive Extensions (Ix)")]
