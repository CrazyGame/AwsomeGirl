﻿using System.Reflection;

[assembly: AssemblyTitle("Comparer extensions for Reactive Extensions (Rx)")]
