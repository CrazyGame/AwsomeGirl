﻿using System.Reflection;

[assembly: AssemblyTitle("Comparer extensions for LINQ")]
